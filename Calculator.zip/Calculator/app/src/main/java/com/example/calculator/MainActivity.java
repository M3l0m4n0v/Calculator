package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnAdd, btnSub, btnDiv, btnMul, btnClean;
    Button btnSqrt, btnSquare, btnPercent;
    EditText num1, num2;
    TextView op, res;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Находим старые элементы
        btnAdd = findViewById(R.id.buttonAdd);
        btnSub = findViewById(R.id.buttonSubtract);
        btnDiv = findViewById(R.id.buttonDivide);
        btnMul = findViewById(R.id.buttonMultiply);
        btnClean = findViewById(R.id.buttonClean);
        num1 = findViewById(R.id.number1);
        num2 = findViewById(R.id.number2);
        op = findViewById(R.id.operation);
        res = findViewById(R.id.result);

        btnSqrt = findViewById(R.id.buttonSqrt);
        btnSquare = findViewById(R.id.buttonSquare);
        btnPercent = findViewById(R.id.buttonPercent);

        btnAdd.setOnClickListener(this);
        btnSub.setOnClickListener(this);
        btnDiv.setOnClickListener(this);
        btnMul.setOnClickListener(this);
        btnClean.setOnClickListener(this);
        btnSqrt.setOnClickListener(this);
        btnSquare.setOnClickListener(this);
        btnPercent.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.buttonClean) {
            num1.setText("");
            num2.setText("");
            op.setText("");
            res.setText("");
            return;
        }

        String text1 = num1.getText().toString();
        String text2 = num2.getText().toString();

        if (text1.isEmpty()) {
            return;
        }

        float n1 = Float.parseFloat(text1);
        float n2 = 0;
        float r = 0;
        int id = v.getId();

        if (id == R.id.buttonSqrt) {
            op.setText("√");
            r = (float) Math.sqrt(n1);
        }
        else if (id == R.id.buttonSquare) {
            op.setText("x²");
            r = n1 * n1;
        }
        else {
            if (text2.isEmpty()) {
                return;
            }
            n2 = Float.parseFloat(text2);

            if (id == R.id.buttonAdd) {
                op.setText("+");
                r = n1 + n2;
            }
            else if (id == R.id.buttonSubtract) {
                op.setText("-");
                r = n1 - n2;
            }
            else if (id == R.id.buttonDivide) {
                op.setText("/");
                if (n2 != 0) {
                    r = n1 / n2;
                }
            }
            else if (id == R.id.buttonMultiply) {
                op.setText("*");
                r = n1 * n2;
            }
            else if (id == R.id.buttonPercent) {
                op.setText("%");
                r = n1 * (n2 / 100);
            }
        }

        // 4. Выводим результат
        res.setText(String.valueOf(r));
    }
}